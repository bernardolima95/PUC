package aed3;
import java.io.*;

public class Produto implements Entidade {

    protected int id;
    protected String nome;
    protected String descricao;
    protected short qtd;
    protected float preco;
    protected String categoria;

    public Produto(String nome, String descricao, short qtd, float preco, String categoria) {
        this.id = -1;
        this.nome = nome;
        this.descricao = descricao;
        this.categoria = categoria;
        this.qtd = qtd;
        this.preco = preco;
    }

    public Produto() {
        this.id = -1;
        this.nome = "";
        this.descricao = "";
        this.categoria = "";
        this.qtd = 0;
        this.preco = 0;
    }

    public int getId() {
        return this.id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String toString() {
        return "Id: " + this.id +
                "\nNome: " + this.nome +
                "\ndescricao: " + this.descricao +
                "\nQtd: " + this.qtd + " unidades." +
                "\nPreço: R$" + this.preco +
                "\ncategoria: " + this.categoria;
    }

    public byte[] toByteArray() throws IOException {
        ByteArrayOutputStream dados = new ByteArrayOutputStream();
        DataOutputStream saida = new DataOutputStream(dados);
        saida.writeInt(this.id);
        saida.writeUTF(this.nome);
        saida.writeUTF(this.descricao);
        saida.writeUTF(this.categoria);
        saida.writeShort(this.qtd);
        saida.writeFloat(this.preco);

        return dados.toByteArray();
    }

    public void fromByteArray(byte[] b) throws IOException {
        ByteArrayInputStream dados = new ByteArrayInputStream(b);
        DataInputStream entrada = new DataInputStream(dados);

        this.id = entrada.readInt();
        this.nome = entrada.readUTF();
        this.descricao = entrada.readUTF();
        this.categoria = entrada.readUTF();
        this.qtd = entrada.readShort();
        this.preco = entrada.readFloat();
    }

}
