package aed3;
import java.util.Scanner;
import java.io.*;

//Bernardo Cerqueira de Lima
//Patrícia Baracho Porto

public class CRUD {
   public static void main(String[] args) {
      int opcao;
      Arquivo<Produto> arqProduto;
      File f;

      try {
         f = new File("produtos.db");
         f.delete();

         arqProduto = new Arquivo<>(Produto.class.getConstructor(), "produtos.db", "Produtos,idx");
         inicializarDB(arqProduto);

         do {
            System.out.println("Digite a operação desejada: \n1- Inclusão\n2- Alteração" +
                    "\n3- Exclusão" + "\n4- Consulta de Produtos\n5- Sair");
            opcao = lerInt();
            menu(opcao, arqProduto);
         } while (opcao != 5);

      } catch (Exception e){
         e.printStackTrace();
      }
   }

   //Metodo de teste que inicializa dois produtos.
   private static void inicializarDB(Arquivo<Produto> arqProduto) throws Exception{
      int id;
      //id = arqProduto.incluir( new Produto("Snickers", "Chocolate, caramelo, amendoim", (short)4, (float) 1.99, "Doces"));
      //id = arqProduto.incluir( new Produto("O Alquimista", "Best-seller do Paulo Coelho", (short)2, (float) 39.99, "Livros"));
   }

   public static int lerInt(){
      Scanner s1 = new Scanner(System.in);
      return Integer.parseInt(s1.nextLine());
   }

   public static float lerFloat(){
      Scanner s1 = new Scanner(System.in);
      return Float.parseFloat(s1.nextLine());
   }

   public static String lerString(){
      Scanner s1 = new Scanner(System.in);
      return s1.nextLine();
   }

   public static void menu(int opcao, Arquivo<Produto> arqProduto) throws Exception{
      switch(opcao){
         case 1:
            System.out.println("-------------------------\nInsercao\n-------------------------\n");
            inserir(arqProduto, 0);//O int id=0 como parametro define que é um incluir comum
            break;
         case 2:
            System.out.println("-------------------------\nAlteração\n-------------------------\n");
            alteracao(arqProduto);
            break;
         case 3:
            System.out.println("-------------------------\nExclusão\n-------------------------\n");
            exclusao(arqProduto);
            break;
         case 4:
            System.out.println("-------------------------\nConsulta de Produtos\n-------------------------\n");
            buscar(arqProduto);
            break;
      }
   }

   //Insere um item no arquivo. O codigo no parametro determina se a inserção é uma original (novo ID) ou uma alteração (mantém ID),
   //com 0 sendo uma inserção original, e qualquer valor alem deste sendo uma alteração, com cod servindo como o ID.
   public static void inserir(Arquivo<Produto> arqProduto, int cod) throws Exception{
      int id;
      System.out.println("Digite o nome do produto a ser incluido, em ate 60 caracteres: ");
      String nome = lerString();
      if (nome.length() > 60 ) nome = nome.substring(0,60);

      System.out.println("Digite a descricao do produto a ser incluido, em ate 120 caracteres: ");
      String descricao = lerString();
      if (descricao.length() > 120 ) descricao = descricao.substring(0,120);

      System.out.println("Digite a categoria do produto a ser incluido, em ate 20 caracteres: ");
      String cat = lerString();
      if (cat.length() > 20 ) cat = cat.substring(0,120);

      System.out.println("Digite a quantidade do produto em estoque: ");
      short qtd = (short)lerInt();

      System.out.println("Digite o preço do produto: ");
      float preco = lerFloat();

      if (cod == 0) {
         id = arqProduto.incluir( new Produto (nome, descricao, qtd, preco, cat));
         System.out.println("Produto incluído com sucesso, ID: "+id);
      }
      else {
         arqProduto.incluirAlt( new Produto (nome, descricao, qtd, preco, cat), cod);//Metodo incluir para caso de alteração, com "cod" = id. Mantem o ID.
         System.out.println("Produto alterado com sucesso, ID: "+cod);
      }
   }

   //Busca o arquivo, procurando um produto com o ID desejado.
   public static void buscar(Arquivo<Produto> arqProduto) throws Exception{
      System.out.println("Digite o ID do produto a ser procurado: ");
      int id = lerInt();
      if (arqProduto.ler(id) != null) System.out.println("\nProduto encontrado:" + arqProduto.ler(id) + "\n");
      else System.out.println("\n Produto não encontrado. \n");
   }

   //Faz o mesmo passo que a busca, e se encontra um arquivo, o deleta.
   public static void exclusao(Arquivo<Produto> arqProduto) throws Exception{
      System.out.println("Digite o ID do produto a ser excluido: ");
      int id = lerInt();
      if (arqProduto.ler(id) != null){
         arqProduto.excluir(id);
         System.out.println("Produto excluido com sucesso.");
      }
      else System.out.println("\n Produto não encontrado. \n");
   }

   //Procura por um produto através seu código de ID, caso o encontre, realiza a remoção e logo após uma inserção codificada com o id do arquivo deletado,
   //efetivamente causando uma alteração das caracteristicas do produto, mantendo o ID original.
   public static void alteracao(Arquivo<Produto> arqProduto) throws Exception{
      System.out.println("Digite o ID do produto a ser alterado: ");
      int id = lerInt();
      if (arqProduto.ler(id) != null){
         arqProduto.excluir(id);
         inserir(arqProduto, id);
         System.out.println("Produto alterado com sucesso.");
      }
      else System.out.println("\n Produto não encontrado. \n");
   }

}